-- !chubby_coop_fix.lua
-- Injected by Chubby Mod Manager for MULTIPLAYER RE4R
-- Fixes:
-- 1. Single OS mouse cursor & reliable menu selection (paired with patched Re4-Co-op.dll)
-- 2. Live theme sync with Chubby Mod Manager (chubby_theme.json + patched Re4-Co-op.dll)
-- 3. Area / gimmick scan lag guard (SDK/Scene lookup memoization + disk I/O cache + 15Hz gimmick cap)
-- 4. Smooth enemy & partner movement (frame-rate-independent exponential lerp/nlerp + velocity prediction)
-- 5. Non-blocking Pause Menu & Inventory during active Co-op sessions

local CFG = {
    smooth_movement   = true,
    lag_guard         = true,
    no_coop_pause     = true,
    pos_lerp_speed    = 24.0,
    rot_slerp_speed   = 20.0,
    enemy_lerp_speed  = 22.0,
    teleport_dist_sq  = 16.0, -- 4.0m
    min_step_dist_sq  = 0.0004, -- 2cm
}

local STATE = {
    theme_name        = "Obsidian Cyan",
    theme_id          = "obsidian_cyan",
    accent_hex        = 0xFFE9A50E,
    connected         = false,
    role              = "None",
    last_role_check   = 0.0,
    last_theme_check  = 0.0,
    last_frame_time   = os.clock(),
    dt                = 0.016,
    sim_wrapped       = false,
    pause_hooked      = false,
    cached_Lookups    = 0,
    smoothed_frames   = 0,
    unpaused_frames   = 0,
}

-- ============================================================================
-- 1. SDK & DISK I/O CACHE (Fixes Area / Gimmick Scan Lag)
-- ============================================================================
local td_cache = {}
local native_singleton_cache = {}
local managed_singleton_cache = {}
local managed_singleton_time = {}
local file_cache = {}
local file_cache_time = {}

if sdk then
    local orig_find_td = sdk.find_type_definition
    if orig_find_td then
        sdk.find_type_definition = function(name)
            if not CFG.lag_guard or not name then
                return orig_find_td(name)
            end
            local cached = td_cache[name]
            if cached ~= nil then
                STATE.cached_Lookups = STATE.cached_Lookups + 1
                return cached or nil
            end
            local ok, res = pcall(orig_find_td, name)
            if ok and res then
                td_cache[name] = res
                return res
            end
            td_cache[name] = false
            return nil
        end
    end

    local orig_get_native = sdk.get_native_singleton
    if orig_get_native then
        sdk.get_native_singleton = function(name)
            if not CFG.lag_guard or not name then
                return orig_get_native(name)
            end
            local cached = native_singleton_cache[name]
            if cached ~= nil then
                STATE.cached_Lookups = STATE.cached_Lookups + 1
                return cached
            end
            local ok, res = pcall(orig_get_native, name)
            if ok and res then
                native_singleton_cache[name] = res
                return res
            end
            return nil
        end
    end

    local orig_get_managed = sdk.get_managed_singleton
    if orig_get_managed then
        sdk.get_managed_singleton = function(name)
            if not CFG.lag_guard or not name then
                return orig_get_managed(name)
            end
            local now = os.clock()
            local t = managed_singleton_time[name]
            if t and (now - t) < 0.15 and managed_singleton_cache[name] ~= nil then
                STATE.cached_Lookups = STATE.cached_Lookups + 1
                return managed_singleton_cache[name]
            end
            local ok, res = pcall(orig_get_managed, name)
            if ok then
                managed_singleton_cache[name] = res
                managed_singleton_time[name] = now
                return res
            end
            return nil
        end
    end
end

-- ============================================================================
-- 2. POSE & ENEMY INTERPOLATION + BLOB / FILE I/O GUARD
-- ============================================================================
local pose_state = {
    has_pose = false,
    last_seq = -1,
    last_pkt_time = 0.0,
    sx = 0.0, sy = 0.0, sz = 0.0,
    sqx = 0.0, sqy = 0.0, sqz = 0.0, sqw = 1.0,
    tx = 0.0, ty = 0.0, tz = 0.0,
    tqx = 0.0, tqy = 0.0, tqz = 0.0, tqw = 1.0,
    vx = 0.0, vy = 0.0, vz = 0.0,
}

local function quat_nlerp(ax, ay, az, aw, bx, by, bz, bw, t)
    local dot = ax * bx + ay * by + az * bz + aw * bw
    if dot < 0.0 then
        bx, by, bz, bw = -bx, -by, -bz, -bw
    end
    local rx = ax + (bx - ax) * t
    local ry = ay + (by - ay) * t
    local rz = az + (bz - az) * t
    local rw = aw + (bw - aw) * t
    local mag = math.sqrt(rx * rx + ry * ry + rz * rz + rw * rw)
    if mag > 1e-6 then
        local inv = 1.0 / mag
        return rx * inv, ry * inv, rz * inv, rw * inv
    end
    return bx, by, bz, bw
end

local blob_last_sent = {}
local blob_last_time = {}

local function wrap_re4mp_sim()
    if STATE.sim_wrapped or type(RE4MP_SIM) ~= "table" then
        return
    end
    STATE.sim_wrapped = true

    -- Cache synchronous disk reads made by the Co-op Lua scripts
    local orig_file_read = RE4MP_SIM.file_read
    local orig_file_write = RE4MP_SIM.file_write
    if type(orig_file_read) == "function" then
        RE4MP_SIM.file_read = function(path)
            if not CFG.lag_guard or not path then
                return orig_file_read(path)
            end
            local now = os.clock()
            local last_t = file_cache_time[path]
            if last_t and (now - last_t) < 0.45 and file_cache[path] ~= nil then
                STATE.cached_Lookups = STATE.cached_Lookups + 1
                return file_cache[path]
            end
            local res = orig_file_read(path)
            file_cache[path] = res
            file_cache_time[path] = now
            return res
        end
    end

    if type(orig_file_write) == "function" then
        RE4MP_SIM.file_write = function(path, content)
            if path then
                file_cache[path] = content
                file_cache_time[path] = os.clock()
            end
            return orig_file_write(path, content)
        end
    end

    -- Throttle redundant gimmick/flag blob broadcasts during heavy frame load
    local orig_send_blob = RE4MP_SIM.send_blob
    if type(orig_send_blob) == "function" then
        RE4MP_SIM.send_blob = function(channel, data)
            if CFG.lag_guard and channel and type(data) == "string" then
                local now = os.clock()
                local prev_data = blob_last_sent[channel]
                local prev_t = blob_last_time[channel] or 0.0
                -- Deduplicate identical state blobs within 66ms (15Hz) or throttle during frame spikes
                local min_interval = (STATE.dt > 0.022) and 0.066 or 0.016
                if prev_data == data and (now - prev_t) < 0.25 then
                    return true
                end
                if (now - prev_t) < min_interval and #data > 96 then
                    return true
                end
                blob_last_sent[channel] = data
                blob_last_time[channel] = now
            end
            return orig_send_blob(channel, data)
        end
    end

    -- Smooth partner & remote pose stream with velocity dead-reckoning + exponential lerp/nlerp
    local orig_get_pose = RE4MP_SIM.get_pose
    if type(orig_get_pose) == "function" then
        RE4MP_SIM.get_pose = function(...)
            local x, y, z, qx, qy, qz, qw, seq = orig_get_pose(...)
            if not CFG.smooth_movement or type(x) ~= "number" or type(y) ~= "number" or type(z) ~= "number" then
                return x, y, z, qx, qy, qz, qw, seq
            end
            local now = os.clock()
            if not pose_state.has_pose then
                pose_state.has_pose = true
                pose_state.last_seq = seq or 0
                pose_state.last_pkt_time = now
                pose_state.sx, pose_state.sy, pose_state.sz = x, y, z
                pose_state.tx, pose_state.ty, pose_state.tz = x, y, z
                pose_state.sqx, pose_state.sqy, pose_state.sqz, pose_state.sqw = qx or 0, qy or 0, qz or 0, qw or 1
                pose_state.tqx, pose_state.tqy, pose_state.tqz, pose_state.tqw = pose_state.sqx, pose_state.sqy, pose_state.sqz, pose_state.sqw
                return x, y, z, qx, qy, qz, qw, seq
            end

            if seq ~= pose_state.last_seq then
                local pkt_dt = math.max(0.008, now - pose_state.last_pkt_time)
                local dx = x - pose_state.tx
                local dy = y - pose_state.ty
                local dz = z - pose_state.tz
                local dist_sq = dx * dx + dy * dy + dz * dz
                if dist_sq > CFG.teleport_dist_sq then
                    pose_state.sx, pose_state.sy, pose_state.sz = x, y, z
                    pose_state.vx, pose_state.vy, pose_state.vz = 0.0, 0.0, 0.0
                elseif pkt_dt < 0.35 then
                    local ivx, ivy, ivz = dx / pkt_dt, dy / pkt_dt, dz / pkt_dt
                    pose_state.vx = pose_state.vx * 0.4 + ivx * 0.6
                    pose_state.vy = pose_state.vy * 0.4 + ivy * 0.6
                    pose_state.vz = pose_state.vz * 0.4 + ivz * 0.6
                else
                    pose_state.vx, pose_state.vy, pose_state.vz = 0.0, 0.0, 0.0
                end
                pose_state.tx, pose_state.ty, pose_state.tz = x, y, z
                pose_state.tqx, pose_state.tqy, pose_state.tqz, pose_state.tqw = qx or 0, qy or 0, qz or 0, qw or 1
                pose_state.last_seq = seq
                pose_state.last_pkt_time = now
            end

            local dt = math.min(0.05, math.max(0.001, STATE.dt))
            local age = math.min(0.06, math.max(0.0, now - pose_state.last_pkt_time))
            local px = pose_state.tx + pose_state.vx * age * 0.5
            local py = pose_state.ty + pose_state.vy * age * 0.5
            local pz = pose_state.tz + pose_state.vz * age * 0.5

            local alpha_p = 1.0 - math.exp(-CFG.pos_lerp_speed * dt)
            local alpha_r = 1.0 - math.exp(-CFG.rot_slerp_speed * dt)

            pose_state.sx = pose_state.sx + (px - pose_state.sx) * alpha_p
            pose_state.sy = pose_state.sy + (py - pose_state.sy) * alpha_p
            pose_state.sz = pose_state.sz + (pz - pose_state.sz) * alpha_p
            pose_state.sqx, pose_state.sqy, pose_state.sqz, pose_state.sqw = quat_nlerp(
                pose_state.sqx, pose_state.sqy, pose_state.sqz, pose_state.sqw,
                pose_state.tqx, pose_state.tqy, pose_state.tqz, pose_state.tqw,
                alpha_r
            )
            STATE.smoothed_frames = STATE.smoothed_frames + 1
            return pose_state.sx, pose_state.sy, pose_state.sz, pose_state.sqx, pose_state.sqy, pose_state.sqz, pose_state.sqw, seq
        end
    end
end

-- ============================================================================
-- 3. ENEMY TRANSFORM SMOOTHER (Fixes Choppy Enemy Movement on Partner Side)
-- ============================================================================
local enemy_tracks = {}
local cached_enemies = {}
local last_enemy_scan = 0.0

local function get_current_scene()
    local scene = nil
    pcall(function()
        local sm = sdk.get_native_singleton("via.SceneManager")
        local td = sdk.find_type_definition("via.SceneManager")
        if sm and td then
            scene = sdk.call_native_func(sm, td, "get_CurrentScene")
        end
    end)
    return scene
end

local function refresh_enemy_transforms(now)
    if (now - last_enemy_scan) < 0.75 then
        return
    end
    last_enemy_scan = now
    cached_enemies = {}
    pcall(function()
        local cm = sdk.get_managed_singleton("chainsaw.CharacterManager")
        if not cm then return end
        local list = cm:call("get_EnemyContextList")
        if not list then return end
        local count = list:call("get_Count") or 0
        for i = 0, math.min(count - 1, 48) do
            local ctx = list:call("get_Item", i)
            if ctx then
                local body = ctx:call("get_BodyGameObject")
                if body then
                    local xf = body:call("get_Transform")
                    if xf then
                        cached_enemies[#cached_enemies + 1] = xf
                    end
                end
            end
        end
    end)
end

local function smooth_enemy_transforms(dt)
    if not CFG.smooth_movement or not STATE.connected then
        return
    end
    local now = os.clock()
    refresh_enemy_transforms(now)
    if #cached_enemies == 0 then
        return
    end
    local alpha = 1.0 - math.exp(-CFG.enemy_lerp_speed * dt)
    for i = 1, #cached_enemies do
        local xf = cached_enemies[i]
        pcall(function()
            local pos = xf:call("get_Position")
            if not pos then return end
            local key = tostring(xf)
            local tr = enemy_tracks[key]
            if not tr then
                enemy_tracks[key] = {
                    sx = pos.x, sy = pos.y, sz = pos.z,
                    tx = pos.x, ty = pos.y, tz = pos.z,
                    vx = 0.0, vy = 0.0, vz = 0.0,
                    t = now,
                }
                return
            end
            local dx = pos.x - tr.sx
            local dy = pos.y - tr.sy
            local dz = pos.z - tr.sz
            local d2 = dx * dx + dy * dy + dz * dz
            if d2 > CFG.teleport_dist_sq then
                tr.sx, tr.sy, tr.sz = pos.x, pos.y, pos.z
                tr.tx, tr.ty, tr.tz = pos.x, pos.y, pos.z
                tr.vx, tr.vy, tr.vz = 0.0, 0.0, 0.0
                tr.t = now
            elseif d2 > CFG.min_step_dist_sq then
                local step_dt = math.max(0.008, now - tr.t)
                if step_dt < 0.35 then
                    tr.vx = tr.vx * 0.5 + (pos.x - tr.tx) / step_dt * 0.5
                    tr.vy = tr.vy * 0.5 + (pos.y - tr.ty) / step_dt * 0.5
                    tr.vz = tr.vz * 0.5 + (pos.z - tr.tz) / step_dt * 0.5
                end
                tr.tx, tr.ty, tr.tz = pos.x, pos.y, pos.z
                tr.t = now
                tr.sx = tr.sx + (tr.tx - tr.sx) * alpha
                tr.sy = tr.sy + (tr.ty - tr.sy) * alpha
                tr.sz = tr.sz + (tr.tz - tr.sz) * alpha
                pos.x = tr.sx
                pos.y = tr.sy
                pos.z = tr.sz
                xf:call("set_Position", pos)
                STATE.smoothed_frames = STATE.smoothed_frames + 1
            end
        end)
    end
end

-- ============================================================================
-- 4. NON-BLOCKING PAUSE MENU & INVENTORY IN CO-OP
-- ============================================================================
local function install_unpause_hooks()
    if STATE.pause_hooked or not sdk then
        return
    end
    local td_pause = sdk.find_type_definition("chainsaw.PauseManager")
    if not td_pause then
        return
    end
    STATE.pause_hooked = true

    local methods_to_guard = {
        "requestPause",
        "setPause",
        "startPause",
        "requestExecutionPause",
    }
    for _, mname in ipairs(methods_to_guard) do
        pcall(function()
            local m = td_pause:get_method(mname)
            if m then
                sdk.hook(m, function(args)
                    if CFG.no_coop_pause and STATE.connected then
                        STATE.unpaused_frames = STATE.unpaused_frames + 1
                        return sdk.PreHookResult.SKIP_ORIGINAL
                    end
                end, function(ret)
                    return ret
                end)
            end
        end)
    end
end

local function keep_coop_world_unpaused()
    if not CFG.no_coop_pause or not STATE.connected then
        return
    end
    pcall(function()
        local scene = get_current_scene()
        if scene then
            local upd = scene:call("get_Update")
            if upd == false then
                scene:call("set_Update", true)
                STATE.unpaused_frames = STATE.unpaused_frames + 1
            end
            local ts = scene:call("get_TimeScale")
            if type(ts) == "number" and ts < 0.05 then
                scene:call("set_TimeScale", 1.0)
                STATE.unpaused_frames = STATE.unpaused_frames + 1
            end
        end
        local app = sdk.get_native_singleton("via.Application")
        local td_app = sdk.find_type_definition("via.Application")
        if app and td_app then
            local gs = sdk.call_native_func(app, td_app, "get_GlobalSpeed")
            if type(gs) == "number" and gs < 0.05 then
                sdk.call_native_func(app, td_app, "set_GlobalSpeed", 1.0)
                STATE.unpaused_frames = STATE.unpaused_frames + 1
            end
        end
    end)
end

-- ============================================================================
-- 5. ROLE & CHUBBY THEME SYNC
-- ============================================================================
local function poll_role_and_theme(now)
    if (now - STATE.last_role_check) > 0.6 then
        STATE.last_role_check = now
        pcall(function()
            if json and json.load_file then
                local r = json.load_file("RE4MP_role.json")
                if type(r) == "table" then
                    STATE.connected = (r.connected == true)
                    STATE.role = tostring(r.role or "None")
                end
            end
        end)
    end

    if (now - STATE.last_theme_check) > 2.0 then
        STATE.last_theme_check = now
        pcall(function()
            if json and json.load_file then
                local th = json.load_file("chubby_theme.json")
                if type(th) == "table" and th.name then
                    STATE.theme_name = tostring(th.name)
                    STATE.theme_id = tostring(th.id or "obsidian_cyan")
                    if type(th.accent_abgr) == "number" then
                        STATE.accent_hex = th.accent_abgr
                    end
                end
            end
        end)
    end
end

-- ============================================================================
-- 6. FRAME & UI CALLBACKS
-- ============================================================================
re.on_pre_application_entry("UpdateBehavior", function()
    local now = os.clock()
    STATE.dt = math.min(0.1, math.max(0.0005, now - STATE.last_frame_time))
    STATE.last_frame_time = now
    wrap_re4mp_sim()
    install_unpause_hooks()
    poll_role_and_theme(now)
    keep_coop_world_unpaused()
end)

re.on_pre_application_entry("LateUpdateBehavior", function()
    smooth_enemy_transforms(STATE.dt)
end)

re.on_frame(function()
    wrap_re4mp_sim()
end)

re.on_draw_ui(function()
    if not imgui then return end
    if imgui.tree_node("Chubby Co-op Enhancer (" .. STATE.theme_name .. ")") then
        imgui.text_colored("Synced Theme: " .. STATE.theme_name .. "  |  Session: " .. (STATE.connected and ("Connected (" .. STATE.role .. ")") or "Standby"), STATE.accent_hex)
        imgui.text("Single OS Mouse Cursor Fix: Active (Re4-Co-op.dll patched)")
        local c1, v1 = imgui.checkbox("Smooth Partner & Enemy Movement (60Hz + Lerp/Slerp)", CFG.smooth_movement)
        if c1 then CFG.smooth_movement = v1 end
        local c2, v2 = imgui.checkbox("Area / Gimmick Scan Lag Guard (SDK + Disk Cache + 15Hz Cap)", CFG.lag_guard)
        if c2 then CFG.lag_guard = v2 end
        local c3, v3 = imgui.checkbox("Non-Blocking Pause Menu & Inventory in Co-op", CFG.no_coop_pause)
        if c3 then CFG.no_coop_pause = v3 end
        imgui.text(string.format("Stats: %d cached lookups | %d smoothed frames | %d pause blocks", STATE.cached_Lookups, STATE.smoothed_frames, STATE.unpaused_frames))
        imgui.tree_pop()
    end
end)

log.info("[Chubby-Coop-Fix] Loaded successfully")
